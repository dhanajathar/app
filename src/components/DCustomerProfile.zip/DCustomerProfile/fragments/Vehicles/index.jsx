import React from 'react'

const Vehicles = () => {
  return (
    <div>Vehicles</div>
  )
}

export default Vehicles