import React from 'react'

const Withdrawal = () => {
  return (
    <div>Withdrawal</div>
  )
}

export default Withdrawal