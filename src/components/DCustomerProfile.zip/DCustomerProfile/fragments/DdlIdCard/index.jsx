import React from 'react'

const DdlIdCard = () => {
  return (
    <div>DdlIdCard</div>
  )
}

export default DdlIdCard